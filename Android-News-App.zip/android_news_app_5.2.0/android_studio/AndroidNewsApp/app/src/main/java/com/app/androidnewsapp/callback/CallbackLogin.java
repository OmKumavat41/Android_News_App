package com.app.androidnewsapp.callback;

import com.app.androidnewsapp.models.User;

public class CallbackLogin {

    public String status = "";
    public String message = "";
    public User user = null;

}
