package com.app.androidnewsapp.callback;

import com.app.androidnewsapp.models.User;

public class CallbackUser {

    public String status = "";
    public User response = null;

}