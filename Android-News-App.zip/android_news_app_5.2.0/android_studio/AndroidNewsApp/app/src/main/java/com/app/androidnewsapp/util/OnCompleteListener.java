package com.app.androidnewsapp.util;

public interface OnCompleteListener {

    void onComplete();

}