package com.app.androidnewsapp.models;

import java.io.Serializable;

public class Report implements Serializable {

    public String type;
    public String post_id;
    public String comment_id;
    public String user_id;
    public String reason;

}
