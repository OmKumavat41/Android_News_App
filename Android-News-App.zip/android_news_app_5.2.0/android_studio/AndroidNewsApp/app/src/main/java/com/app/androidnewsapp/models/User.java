package com.app.androidnewsapp.models;

import java.io.Serializable;

public class User implements Serializable {

    public String id;
    public String user_type;
    public String name;
    public String email;
    public String status;
    public String password;
    public String image;
    public String response;

}
