package com.app.androidnewsapp.models;

public class App {

    public String package_name = "";
    public String status = "";
    public String redirect_url = "";

}
